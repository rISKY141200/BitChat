# BT Chat — chat 2 HP via Bluetooth

## Cara build
1. Buka folder `BtChat` di Android Studio (Koala / lebih baru), tunggu Gradle sync.
2. Colok HP Android (USB debugging aktif) lalu Run. Pasang di KEDUA HP.
   (atau Build > Build APK, lalu kirim APK ke HP satunya)

## Cara pakai
1. Pair kedua HP sekali lewat Pengaturan > Bluetooth.
2. Buka app di kedua HP, izinkan akses Bluetooth.
3. Pertama kali: pilih HP lawan dari daftar perangkat terpasang.
4. Selanjutnya cukup buka app di kedua HP, sambung otomatis.
5. Menu ⋮ : ganti latar (foto dari galeri), reset latar, hapus riwayat, ganti HP lawan.

## Catatan
- Pakai Bluetooth Classic (RFCOMM), Android saja (iPhone tidak bisa).
- Sambungan aktif selama app terbuka (tidak ada service latar belakang).
- File diterima tersimpan di Android/data/com.rizky.btchat/files/received/.
- Kecepatan kirim file sekitar 100-200 KB/s (batas Bluetooth Classic).
