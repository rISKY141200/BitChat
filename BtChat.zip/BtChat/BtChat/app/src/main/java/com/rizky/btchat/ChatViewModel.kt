package com.rizky.btchat

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import java.io.File
import java.util.concurrent.Executors
import kotlin.concurrent.thread

data class ChatMsg(
    val id: Long,
    val mine: Boolean,
    val text: String? = null,
    val fileName: String? = null,
    val filePath: String? = null,
    val fileSize: Long = 0,
    val time: Long = System.currentTimeMillis()
)

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val prefs = ctx.getSharedPreferences("btchat", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    // Data obrolan dan koneksi ada di ChatStore/BtService, jadi tetap hidup walau layar ditutup
    val messages: List<ChatMsg> get() = ChatStore.messages
    val state: ConnState get() = ChatStore.state
    val progress: Float? get() = ChatStore.progress
    val sending: Boolean get() = ChatStore.sending

    var peerName by mutableStateOf(prefs.getString("peer_name", null)); private set
    var peerAddress by mutableStateOf(prefs.getString("peer_addr", null)); private set
    var background by mutableStateOf<ImageBitmap?>(null); private set

    init {
        ChatStore.init(ctx)
        loadBackground()
    }

    // ---------- Koneksi (dijalankan BtService) ----------
    fun start() {
        if (peerAddress == null) return
        ContextCompat.startForegroundService(ctx, Intent(ctx, BtService::class.java))
    }

    private fun stopService() {
        ctx.stopService(Intent(ctx, BtService::class.java))
        ChatStore.state = ConnState.IDLE
    }

    fun setPeer(name: String, address: String) {
        stopService()
        prefs.edit().putString("peer_name", name).putString("peer_addr", address).apply()
        peerName = name; peerAddress = address
    }

    fun forgetPeer() {
        stopService()
        prefs.edit().remove("peer_name").remove("peer_addr").apply()
        peerName = null; peerAddress = null
    }

    // ---------- Kirim ----------
    fun sendText(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        if (state != ConnState.CONNECTED) { toast("Belum tersambung ke HP lawan"); return }
        io.execute {
            val ok = BtService.instance?.sendText(text) ?: false
            main.post { if (ok) ChatStore.add(ChatMsg(ChatStore.newId(), true, text = text)) else toast("Gagal mengirim pesan") }
        }
    }

    fun sendFile(uri: Uri) {
        if (state != ConnState.CONNECTED) { toast("Belum tersambung ke HP lawan"); return }
        io.execute {
            try {
                val name = ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { if (it.moveToFirst()) it.getString(0) else null }
                    ?: "file_${System.currentTimeMillis()}"
                val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "sent").apply { mkdirs() }
                val local = uniqueFile(dir, name)
                ctx.contentResolver.openInputStream(uri)?.use { i -> local.outputStream().use { i.copyTo(it) } }
                    ?: throw IllegalStateException("File tidak bisa dibuka")
                val ok = BtService.instance?.sendFile(local, name) ?: false
                main.post {
                    if (ok) ChatStore.add(ChatMsg(ChatStore.newId(), true, fileName = name, filePath = local.absolutePath, fileSize = local.length()))
                    else toast("Gagal mengirim file")
                }
            } catch (e: Exception) {
                main.post { toast("Gagal mengirim file") }
            }
        }
    }

    // ---------- Latar obrolan ----------
    fun setBackground(uri: Uri) {
        thread {
            val bmp = decodeUri(ctx, uri, 1600) ?: return@thread
            File(ctx.filesDir, "chat_bg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            val ib = bmp.asImageBitmap()
            main.post { background = ib }
        }
    }

    fun resetBackground() {
        File(ctx.filesDir, "chat_bg.jpg").delete()
        background = null
    }

    private fun loadBackground() {
        val f = File(ctx.filesDir, "chat_bg.jpg")
        if (f.exists()) decodeFile(f.absolutePath, 1600)?.let { background = it.asImageBitmap() }
    }

    // ---------- Riwayat ----------
    fun clearHistory() { ChatStore.clear() }

    private fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    override fun onCleared() { io.shutdown() }
}
