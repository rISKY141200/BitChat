package com.rizky.btchat

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF075E54)
private val DefaultBg = Color(0xFFECE5DD)

class MainActivity : ComponentActivity() {
    private val vm: ChatViewModel by viewModels()

    override fun onStart() { super.onStart(); ChatStore.uiVisible = true }
    override fun onStop() { ChatStore.uiVisible = false; super.onStop() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Green)) { App(vm) }
        }
    }
}

fun hasBtPermission(ctx: Context) =
    Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

private fun btAdapter(ctx: Context): BluetoothAdapter? =
    (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

@Composable
fun App(vm: ChatViewModel) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasBtPermission(ctx)) }
    var btOn by remember { mutableStateOf(btAdapter(ctx)?.isEnabled == true) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val enableLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        btOn = btAdapter(ctx)?.isEnabled == true
    }

    val storageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT in 23..28 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) storageLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }

    LaunchedEffect(Unit) {
        if (!granted && Build.VERSION.SDK_INT >= 31) permLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(granted) {
        if (granted && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) {
        while (true) { btOn = btAdapter(ctx)?.isEnabled == true; delay(1000) }
    }

    when {
        btAdapter(ctx) == null -> Notice("HP ini tidak mendukung Bluetooth.", null) {}
        !granted -> Notice("Aplikasi butuh izin Bluetooth untuk terhubung ke HP lawan.", "Berikan izin") {
            permLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        }
        !btOn -> Notice("Bluetooth sedang mati.", "Nyalakan Bluetooth") {
            enableLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
        }
        vm.peerAddress == null -> DevicePicker(vm)
        else -> {
            LaunchedEffect(vm.peerAddress) { vm.start() }
            ChatScreen(vm)
        }
    }
}

@Composable
fun Notice(message: String, button: String?, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(message, fontSize = 16.sp)
        if (button != null) {
            Spacer(Modifier.height(16.dp))
            Button(onClick = onClick) { Text(button) }
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun DevicePicker(vm: ChatViewModel) {
    val ctx = LocalContext.current
    val adapter = remember { btAdapter(ctx) }
    var devices by remember { mutableStateOf(adapter?.bondedDevices?.toList() ?: emptyList()) }

    Column(Modifier.fillMaxSize().background(Color.White).padding(24.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("Pilih HP lawan bicara", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Pastikan kedua HP sudah dipasangkan (pair) lewat Pengaturan Bluetooth. Pilihan ini hanya sekali; berikutnya aplikasi tersambung otomatis.")
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }) { Text("Pengaturan BT") }
            OutlinedButton(onClick = { devices = adapter?.bondedDevices?.toList() ?: emptyList() }) { Text("Segarkan") }
        }
        Spacer(Modifier.height(12.dp))
        if (devices.isEmpty()) Text("Belum ada perangkat yang dipasangkan.", color = Color.Gray)
        LazyColumn {
            items(devices) { d ->
                Card(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { vm.setPeer(d.name ?: d.address, d.address) },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF2F2F2))
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(d.name ?: "(tanpa nama)", fontWeight = FontWeight.SemiBold)
                        Text(d.address, fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val pickBg = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { it?.let(vm::setBackground) }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let(vm::sendFile) }

    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.size - 1)
    }

    val status = when (vm.state) {
        ConnState.CONNECTED -> "Tersambung"
        ConnState.CONNECTING -> "Menghubungkan…"
        ConnState.IDLE -> "Terputus"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(vm.peerName ?: "Chat", fontWeight = FontWeight.SemiBold)
                        Text(status, fontSize = 12.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Green, titleContentColor = Color.White, actionIconContentColor = Color.White
                ),
                actions = {
                    Box {
                        IconButton(onClick = { menu = true }) { Text("⋮", color = Color.White, fontSize = 24.sp) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Ganti latar obrolan") }, onClick = {
                                menu = false
                                pickBg.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            })
                            DropdownMenuItem(text = { Text("Reset latar") }, onClick = { menu = false; vm.resetBackground() })
                            DropdownMenuItem(text = { Text("Hapus riwayat") }, onClick = { menu = false; vm.clearHistory() })
                            DropdownMenuItem(text = { Text("Ganti HP lawan") }, onClick = { menu = false; vm.forgetPeer() })
                        }
                    }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(DefaultBg)) {
            val bg = vm.background
            if (bg != null) {
                Image(bg, null, Modifier.matchParentSize(), contentScale = ContentScale.Crop)
                Box(Modifier.matchParentSize().background(Color(0x14000000)))
            }
            Column(Modifier.fillMaxSize()) {
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = PaddingValues(vertical = 8.dp)) {
                    items(vm.messages, key = { it.id }) { m -> Bubble(m) { openFile(ctx, it) } }
                }
                val p = vm.progress
                if (p != null) {
                    Surface(Modifier.fillMaxWidth(), color = Color(0xE6FFFFFF)) {
                        Column(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                            Text((if (vm.sending) "Mengirim file… " else "Menerima file… ") + "${(p * 100).toInt()}%", fontSize = 12.sp)
                            LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = CircleShape, color = Color.White, shadowElevation = 1.dp) {
                        IconButton(onClick = { pickFile.launch("*/*") }) { Text("📎", fontSize = 20.sp) }
                    }
                    Spacer(Modifier.width(6.dp))
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Ketik pesan") },
                        shape = RoundedCornerShape(24.dp), maxLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                            focusedBorderColor = Color.Transparent, unfocusedBorderColor = Color.Transparent
                        )
                    )
                    Spacer(Modifier.width(6.dp))
                    FilledIconButton(
                        onClick = { vm.sendText(input); input = "" },
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Green)
                    ) { Text("➤", color = Color.White) }
                }
            }
        }
    }
}

@Composable
fun Bubble(m: ChatMsg, onOpen: (ChatMsg) -> Unit) {
    val mine = m.mine
    val shape = if (mine) RoundedCornerShape(12.dp, 12.dp, 2.dp, 12.dp) else RoundedCornerShape(12.dp, 12.dp, 12.dp, 2.dp)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (mine) Color(0xFFDCF8C6) else Color.White,
            shape = shape, shadowElevation = 1.dp,
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Column(Modifier.padding(8.dp)) {
                if (m.fileName != null) {
                    Column(Modifier.clickable { onOpen(m) }) {
                        val path = m.filePath
                        if (path != null && isImage(m.fileName)) {
                            val thumb = remember(path) { decodeFile(path, 400)?.asImageBitmap() }
                            if (thumb != null) {
                                Image(thumb, null, Modifier.fillMaxWidth().heightIn(max = 220.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
                                Spacer(Modifier.height(4.dp))
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("📄", fontSize = 24.sp)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(m.fileName, fontWeight = FontWeight.Medium)
                                Text(formatSize(m.fileSize), fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }
                } else {
                    Text(m.text ?: "")
                }
                Text(
                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(m.time)),
                    fontSize = 10.sp, color = Color.Gray, modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}

private fun openFile(ctx: Context, m: ChatMsg) {
    val path = m.filePath ?: return
    val f = File(path)
    if (!f.exists()) { Toast.makeText(ctx, "File tidak ditemukan", Toast.LENGTH_SHORT).show(); return }
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, mimeOf(m.fileName ?: f.name))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try { ctx.startActivity(intent) }
    catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "Tidak ada aplikasi untuk membuka file ini", Toast.LENGTH_SHORT).show() }
}
