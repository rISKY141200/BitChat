package com.rizky.btchat

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Data obrolan yang dipakai bersama oleh layar (ViewModel) dan BtService. */
object ChatStore {
    private var appCtx: Context? = null

    val messages = mutableStateListOf<ChatMsg>()
    var state by mutableStateOf(ConnState.IDLE)
    var progress by mutableStateOf<Float?>(null)
    var sending by mutableStateOf(false)

    @Volatile var uiVisible = false

    fun init(ctx: Context) {
        if (appCtx != null) return
        appCtx = ctx.applicationContext
        load()
    }

    fun newId() = System.nanoTime()

    fun add(m: ChatMsg) { messages.add(m); save() }

    fun clear() { messages.clear(); save() }

    private fun save() {
        val ctx = appCtx ?: return
        val arr = JSONArray()
        messages.forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id); put("mine", m.mine); put("time", m.time); put("size", m.fileSize)
                m.text?.let { put("text", it) }
                m.fileName?.let { put("fn", it) }
                m.filePath?.let { put("fp", it) }
            })
        }
        runCatching { File(ctx.filesDir, "history.json").writeText(arr.toString()) }
    }

    private fun load() {
        val ctx = appCtx ?: return
        val f = File(ctx.filesDir, "history.json")
        if (!f.exists()) return
        runCatching {
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                messages.add(
                    ChatMsg(
                        id = o.getLong("id"), mine = o.getBoolean("mine"),
                        text = o.optString("text").ifEmpty { null },
                        fileName = o.optString("fn").ifEmpty { null },
                        filePath = o.optString("fp").ifEmpty { null },
                        fileSize = o.optLong("size"), time = o.optLong("time")
                    )
                )
            }
        }
    }
}
