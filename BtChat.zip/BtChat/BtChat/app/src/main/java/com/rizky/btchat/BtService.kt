package com.rizky.btchat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.File
import java.util.concurrent.Executors

/**
 * Foreground service: koneksi Bluetooth tetap hidup walau aplikasi ditutup atau
 * ditinggal. Pesan dan file yang masuk diproses di sini.
 */
class BtService : Service(), BtManager.Listener {

    companion object {
        const val ACTION_STOP = "com.rizky.btchat.STOP"
        private const val CH_CONN = "btchat_conn"
        private const val CH_MSG = "btchat_msg"
        private const val ID_CONN = 1
        private const val ID_MSG = 2

        @Volatile var instance: BtService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var manager: BtManager? = null
    private var currentAddr: String? = null

    private val prefs by lazy { getSharedPreferences("btchat", Context.MODE_PRIVATE) }
    private val nm by lazy { getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        ChatStore.init(this)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH_CONN, "Koneksi Btchat", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_MSG, "Pesan masuk", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }

        try {
            ServiceCompat.startForeground(
                this, ID_CONN, connNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        val addr = prefs.getString("peer_addr", null)
        if (addr == null) {
            shutdown()
            return START_NOT_STICKY
        }

        if (manager != null && addr != currentAddr) {
            manager?.stop(); manager = null
        }
        if (manager == null) {
            currentAddr = addr
            manager = BtManager(applicationContext, this).also { it.start(addr) }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        manager?.stop(); manager = null
        ChatStore.state = ConnState.IDLE
        ChatStore.progress = null
        io.shutdown()
        instance = null
        super.onDestroy()
    }

    private fun shutdown() {
        manager?.stop(); manager = null
        ChatStore.state = ConnState.IDLE
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------- Dipakai ChatViewModel ----------
    fun sendText(text: String): Boolean = manager?.sendText(text) ?: false

    fun sendFile(file: File, displayName: String): Boolean = manager?.sendFile(file, displayName) ?: false

    // ---------- BtManager.Listener (selalu di main thread) ----------
    override fun onState(s: ConnState) {
        ChatStore.state = s
        runCatching { nm.notify(ID_CONN, connNotification()) }
    }

    override fun onText(text: String) {
        ChatStore.add(ChatMsg(ChatStore.newId(), false, text = text))
        notifyIncoming(text)
    }

    override fun onFile(name: String, file: File, size: Long) {
        ChatStore.add(ChatMsg(ChatStore.newId(), false, fileName = name, filePath = file.absolutePath, fileSize = size))
        io.execute {
            val ok = FileSaver.saveToDownloads(applicationContext, file, file.name)
            main.post {
                Toast.makeText(
                    applicationContext,
                    if (ok) "Tersimpan di Download/Btchat" else "File diterima, tetapi gagal disimpan ke penyimpanan",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        notifyIncoming("File: $name")
    }

    override fun onProgress(sending: Boolean, fraction: Float?) {
        ChatStore.sending = sending
        ChatStore.progress = fraction
    }

    // ---------- Notifikasi ----------
    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun connNotification(): Notification {
        val peer = prefs.getString("peer_name", null) ?: "HP lawan"
        val text = when (ChatStore.state) {
            ConnState.CONNECTED -> "Tersambung ke $peer"
            ConnState.CONNECTING -> "Menghubungkan ke $peer…"
            ConnState.IDLE -> "Menunggu $peer"
        }
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, BtService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH_CONN)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Btchat")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent())
            .addAction(0, "Berhenti", stop)
            .build()
    }

    private fun notifyIncoming(body: String) {
        if (ChatStore.uiVisible) return
        val peer = prefs.getString("peer_name", null) ?: "Btchat"
        val n = NotificationCompat.Builder(this, CH_MSG)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle(peer)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        runCatching { nm.notify(ID_MSG, n) }
    }
}
